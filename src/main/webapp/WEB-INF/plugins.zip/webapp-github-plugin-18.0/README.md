oXygen XML Web Author GitHub connector
=======================
This plugin enables oXygen XML Web Author to open and commit files on GitHub.
        
Open
----


In order to open a github file, you should use the dedicated action that appears on the oXygen XML Web Author's dashboard.

Commit
------

        
When you open a GitHub file, a *GitHub* button appears on the toolbar. In its dropdown menu, there is a "Commit to GitHub" action. When youi perform that action, you will be asked to provide:
 * provide the commit message
 * (optional) the name of a new branch on which this commit goes

Building the plugin
-------------------

You should have Java and Maven installed. Then just run:
```
mvn package
```
The plugin `jar` file should be available in the `target` folder.
