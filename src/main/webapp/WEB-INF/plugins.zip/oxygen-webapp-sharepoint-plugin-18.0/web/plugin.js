(function () {
    var isOnDashboard = false;

    /**
     * @constructor Creates the editor handler.
     */
    function SharePointEditorHandler() {
        this.options = null;
        this.editor = null;
        goog.events.listen(workspace, sync.api.Workspace.EventType.BEFORE_EDITOR_LOADED, goog.bind(this.beforeEditorLoaded, this));
        
        // Listen for Dashboard events
        goog.events.listen(workspace, sync.api.Workspace.EventType.DASHBOARD_LOADED, function(e) {
            isOnDashboard = true;
            var anchor = window.location.hash;
            if (anchor) {
            	// Retry the actions
                if (anchor.indexOf(SharePointOpenAction.ID) != -1) {
                    if (sharepointOpenAction) {
                      // Remove the fragment part of the url because users may want tot copy the url to give to someone else
                      location.hash = '';
                    	sharepointOpenAction.actionPerformed();
                    }
                } else if (anchor.indexOf(SharePointCreateDocumentAction.ID) != -1) {
                	if (sharepointCreateAction) {
                    // Remove the fragment part of the url because users may want tot copy the url to give to someone else
                    location.hash = '';
                		sharepointCreateAction.actionPerformed();
                	}
                }
            }
        });
    }

    /*
     * @param e The event generated before the editor is loaded
     */
    SharePointEditorHandler.prototype.beforeEditorLoaded = function (e) {
        this.options = e.options;
        this.isCheckedOut = false;
        this.editor = e.editor;
        var url = e.options.url;

        if (this.isSharePointUrl(url)) {
            if (window.location.href.indexOf("sharepoint-token-provided=true") != -1) {
                var opener = window.opener || window.parent;
                window.addEventListener("message", goog.bind(this.receiveMessage, this), false);
                opener.postMessage({ id: "token_request" }, "*");
                e.preventDefault();
            } else {
                e.preventDefault();
                loginManager.authenticateUser(goog.bind(this.configureEditor, this));
            }
        }
    };

    /*
     * Checks if the given URL represents a SharePoint URL.
     *
     * @param url The url to check.
     */
    SharePointEditorHandler.prototype.isSharePointUrl = function(url) {
        return url.match(/^spo-https?:/);
    }

    /**
     * Handles the message reception event.
     * @param event The source event.
     */
    SharePointEditorHandler.prototype.receiveMessage = function(event) {
        var token = event.data.token;
        var self = this;
        $.ajax({
            type: 'POST',
            url: '../plugins-dispatcher/sp-oauth?token=' + token,
            success: function () {
                goog.events.listen(
                    self.editor,
                    sync.api.Editor.EventTypes.LINK_OPENED,
                    function (e) {
                        delete e.params["sharepoint-token-provided"];
                        e.preventDefault();
                        // TODO: pass other parameters (e.g. DITA Map)
                        window.location.search = "?sharepoint-token-provided=true&url=" + encodeURIComponent(e.url);
                    });
                loginManager.authenticateUser(goog.bind(self.configureEditor, self))
            }
        });
    }

    /**
     * Configures the editor.
     */
    SharePointEditorHandler.prototype.configureEditor = function() {
        var sessionInfo = loginManager.sessionInfo;
        if (sessionInfo) {
            var user = sessionInfo.user;
            if (user) {
                this.options.userName = user.name;
            }
        }

        var url = this.options.url;
        goog.events.listen(
            workspace,
            sync.api.Workspace.EventType.EDITOR_LOADED,
            function (e) {
                if(window.location.href.indexOf("preview=true") != -1) {
                    console.log('Preview....');
                    // Hide the components surrounding the editor
                    var hiddenIds = ['header', 'footer', 'left-panel'];
                    hiddenIds.forEach(
                        function(id) {
                            var elem = document.getElementById(id);
                            elem.style.display = 'none';
                        }
                    );
                    // Hide widgets
                    var classes = ['.ui-layout-resizer', '.ui-layout-resizer-east.ui-layout-resizer', '.ui-layout-toggler'];
                    classes.forEach(
                        function(cls) {
                            var e = document.querySelector(cls);
                            if (e) {
                                e.style.display = 'none';
                            }
                        }
                    );

                    var editorContent = document.getElementById('editorContent');
                    editorContent.style.width = '100%';
                    editorContent.style.height = '100%';
                    editorContent.style.top = '0';

                    document.getElementById('editor-frame').style.overflow = 'hidden';

                    var oxyDoc = document.querySelector('.oxy-document');
                    oxyDoc.style.transform = 'scale(0.6, 0.6)';
                    oxyDoc.style.transformOrigin = '0 0';
                    oxyDoc.style.position = 'fixed';
                    oxyDoc.style.top = '0';
                    oxyDoc.style.left = '0';
                    oxyDoc.style.width = '166%';
                }
                workspace.setUrlChooser(fileBrowser);
            });

        // The editor is about to be loaded.
        var editor = this.editor;
        editor.load(this.options);

        this.checkIsCheckedOut();
        // Register check in, check out actions.
        this.registerSharePointActions(editor);

        // Listen for messages sent from the server-side code.
        goog.events.listen(editor, sync.api.Editor.EventTypes.CUSTOM_MESSAGE_RECEIVED, goog.bind(this.handleCustomMessage, this));

    };

    /**
     * Registers the SharePoint specific actions.
     *
     * @param editor The current editor object.
     */
    SharePointEditorHandler.prototype.registerSharePointActions = function(editor) {

        this.checkOutAction = new CheckOutAction(editor, this);
        this.checkInAction = new CheckInAction(editor, this);
        this.discardCheckOutAction = new DiscardCheckOutAction(editor, this);

        // Register the Checkout action.
        editor.getActionsManager().registerAction(CheckOutAction.ID, this.checkOutAction);
        // Register the Check in action.
        editor.getActionsManager().registerAction(CheckInAction.ID, this.checkInAction);
        // Register the Discard Check Out action.
        editor.getActionsManager().registerAction(DiscardCheckOutAction.ID, this.discardCheckOutAction);

        var actionsIds = [CheckOutAction.ID, CheckInAction.ID, DiscardCheckOutAction.ID];

        // Add the actions into the 'Builtin' toolbar
        goog.events.listen(editor, sync.api.Editor.EventTypes.ACTIONS_LOADED, function(e) {
            var actionsConfig = e.actionsConfiguration;

            var builtinToolbar = null;
            if (actionsConfig.toolbars) {
                for (var i = 0; i < actionsConfig.toolbars.length; i++) {
                    var toolbar = actionsConfig.toolbars[i];
                    if (toolbar.name == "Builtin") {
                        builtinToolbar = toolbar;
                    }
                }
            }

            if (builtinToolbar) {
                // Add a separator
                builtinToolbar.children.push({
                    type: "sep"
                });

                // Add the SharePoint actions
                for(var i = 0; i < actionsIds.length; i++) {
                    builtinToolbar.children.push({
                        id: actionsIds[i],
                        type: "action"
                    });
                }                
                setTimeout(function(){
                    editor.getActionsManager().refreshActionsStatus(CheckOutAction.ID, CheckInAction.ID, DiscardCheckOutAction.ID);
                }, 0);
            }
        });
    }

    /**
     * Decides what to do depending on the current context.
     *
     * @param e The source event.
     */
    SharePointEditorHandler.prototype.handleCustomMessage = function(e) {
        var context = e.context;
        var editor = e.editor;
        var userInfo = loginManager.sessionInfo;
        if (userInfo) {
            e.options.userName = userInfo.name;
        }
        loginManager.authenticateUser(function () {
            // After the user was logged in, retry the operation that failed.
            if (context == sync.api.Editor.WebappMessageReceived.Context.LOAD) {
                // If the document was loading, we try to reload the whole webapp.
                window.location.reload();
            } else if (context == sync.api.Editor.WebappMessageReceived.Context.EDITING) {
                // During editing, only references can trigger re-authentication. Refresh them.
                editor.getActionsManager().getActionById('Author/Refresh_references').actionPerformed();
            } else if (context == sync.api.Editor.WebappMessageReceived.Context.SAVE) {
                // Currently there is no API to re-try saving, but it will be.
                editor.getActionsManager().getActionById('Author/Save').actionPerformed(function () { });
            } else if (context == sync.api.Editor.WebappMessageReceived.Context.IMAGE) {
                // The browser failed to retrieve an image - reload it.
                var images = document.querySelectorAll('img[data-src]');
                for (var i = 0; i < images.length; i++) {
                    images[i].src = goog.dom.dataset.get(images[i], 'src');
                }
            }
        });
    }

    /**
     * Toggles the checked out state of the current document.
     *
     * @param isCheckedOut true if the document is checked out.
     */
    SharePointEditorHandler.prototype.setCheckedOut = function(isCheckedOut) {
        this.isCheckedOut = isCheckedOut;
        editorHandler.editor.actionsManager.refreshActionsStatus(CheckOutAction.ID, CheckInAction.ID, DiscardCheckOutAction.ID);
        var decorators = document.querySelector('.decorators');
        if (isCheckedOut) {
            decorators.innerHTML = '<span id=\"sp-check-out-deco\"></span>';
        } else {
            var decoSpan = decorators.querySelector('span#sp-check-out-deco');
            if (decoSpan) {
                decorators.removeChild(decoSpan);
            }
        }
    }

    /**
     * Verifies if the current document is checked out or not.
     */
    SharePointEditorHandler.prototype.checkIsCheckedOut = function() {
        var reqContent = {
            action: 'is.checked.out',
            url : this.options.url
        };
        var editorHandler = this;
        goog.net.XhrIo.send("../plugins-dispatcher/sp-action", function(e) {
            var xhr = e.target;
            var response = xhr.getResponseJson();
            var isCheckedOut = false;
            if (response) {
                isCheckedOut = response["is.checked.out"];
            }
            editorHandler.setCheckedOut(isCheckedOut);
        }, 'POST', JSON.stringify(reqContent));
    }

    /**
     * Display a message dialog.
     *
     * @param title The dialog's title.
     * @param message The dialog's content.
     */
    SharePointEditorHandler.prototype.showMessageDialog = function(title, message) {
        var msgDialog = workspace.createDialog();
        msgDialog.setButtonConfiguration(sync.api.Dialog.ButtonConfiguration.OK);
        var dialogHtml =
            '<table>' +
            '   <col width="16px"/>' +
            '   <col width="400px"/>' +
            '   <tr>' +
            '       <td><div class="sp-message-err-icon"></div></td>' +
            '       <td><div class="sp-message">' + message + '</div></td>' +
            '   </tr>' +
            '</table>';
        msgDialog.getElement().innerHTML = dialogHtml;
        msgDialog.setTitle(title);
        msgDialog.show();
    }

    ////////////////////////////////////// Actions ///////////////////////////////////////////////////////////

    /**
     * The action that perform a Check Out operation on the current document.
     */
    var CheckOutAction = function(editor, editorHandler) {
        this.editor = editor;
        this.editorHandler = editorHandler;
    };

    /**
     * @type {string} The action's ID.
     */
    CheckOutAction.ID = 'sp.checkout';

    goog.inherits(CheckOutAction, sync.actions.AbstractAction);

    /** @override */
    CheckOutAction.prototype.getDisplayName = function() {
        return 'Check Out';
    };

    // The actual action execution.
    CheckOutAction.prototype.actionPerformed = function(callback) {
        var reqContent = {
            action: 'check.out',
            url : this.editor.options.url
        };
        var coAction = this;
        goog.net.XhrIo.send("../plugins-dispatcher/sp-action", function(e) {
            var xhr = e.target;
            var result = xhr.getResponseJson();
            if (result.successful) {
                coAction.editorHandler.setCheckedOut(true);
                coAction.editor.problemReporter.showInfo('Document checked out.', true);
            } else if (result.error){
                coAction.editorHandler.showMessageDialog('Check out failed', result.error);
                coAction.editorHandler.checkIsCheckedOut();
            }
            callback && callback();
        }, 'POST', JSON.stringify(reqContent));
    };

    /** @override */
    CheckOutAction.prototype.getLargeIcon = function(devicePixelRation) {
        var iconUrl = sync.util.computeHdpiIcon('../plugin-resources/sharepoint/CheckOut24.png');
        return iconUrl;
    };

    /** @override */
    CheckOutAction.prototype.isEnabled = function() {
        return !this.editorHandler.isCheckedOut;
    }

    /** @override */
    CheckOutAction.prototype.getDescription = function() {
        return "Check out this document from the library.\n" +
            "A checked out document cannot be edited by anyone else while it remains checked out.";
    };

    /**
     * The action that perform a Check In operation on the current document.
     */
    var CheckInAction = function(editor, editorHandler) {
        this.editor = editor;
        this.editorHandler = editorHandler;
    };
    goog.inherits(CheckInAction, sync.actions.AbstractAction);

    /**
     * @type {string} The action's ID.
     */
    CheckInAction.ID = 'sp.checkin';

    /** @override */
    CheckInAction.prototype.getDisplayName = function() {
        return 'Check In';
    };

    // The actual action execution.
    CheckInAction.prototype.actionPerformed = function(callback) {

        if (this.editor.isDirty()) {
            var msgDialog = workspace.createDialog();
            msgDialog.setButtonConfiguration(sync.api.Dialog.ButtonConfiguration.YES_NO);
            var dialogHtml =
                '<div class="sp-message">' +
                '   You have unsaved content in the document. ' +
                '   The modified content will not be included in the checked in version. ' +
                '   <br/><br/>Do you want to save?' +
                '</div>';
            msgDialog.getElement().innerHTML = dialogHtml;
            msgDialog.setTitle("Save");

            var action = this;
            msgDialog.onSelect(function (key) {
                if (key == 'yes') {
                    var saveAction = action.editor.getActionsManager().getActionById('Author/Save');
                    if (saveAction) {
                        saveAction.actionPerformed(goog.bind(action.checkIn, action, callback));
                    }
                } else {
                    action.checkIn(callback);
                }
            });
            msgDialog.show();
        } else {
            this.checkIn(callback);
        }
    };

    /**
     * Performs the check in.
     *
     * @param callback The callback function.
     */
    CheckInAction.prototype.checkIn = function(callback) {
        var checkInDlg = workspace.createDialog();
        checkInDlg.setButtonConfiguration(sync.api.Dialog.ButtonConfiguration.OK_CANCEL);
        var dialogHtml =
            '<div class="sp-check-in">' +
            '   <div class="sp-check-in-type">\n' +
            '       <span class="sp-message">What kind of version would you like to check in?</span>' +
            '       <div class="sp-radio vertical-align-children"><label><input type="radio" name="check-in-type" id="check-in-minor"><span>Minor version</span></label></div>\n' +
            '       <div  class="sp-radio vertical-align-children"><label><input type="radio" name="check-in-type" id="check-in-major"><span>Major version</span></label></div>\n' +
            '   </div>\n' +
            '   <div class="check-in-comment">' +
            '       <span class="sp-message">Describe what has changed in this version:</span>' +
            '       <span class="sp-textarea"><textarea  rows="5" cols="50" id="check-in-comment"></textarea></span>\n' +
            '   </div>\n'+
            '</div>';
        checkInDlg.getElement().innerHTML = dialogHtml;
        checkInDlg.setTitle('Check in');

        checkInDlg.getElement().querySelector('#check-in-minor').checked = true;

        var ciAction = this;
        checkInDlg.onSelect(function (key) {
            if (key == 'ok') {
                var textarea = checkInDlg.getElement().querySelector('#check-in-comment');
                var comment = textarea.value;
                var type;
                if (checkInDlg.getElement().querySelector('#check-in-major').checked) {
                    type = 1;
                } else {
                    type = 0;
                }
                var reqContent = {
                    'action': 'check.in',
                    'url' : ciAction.editor.options.url,
                    'comment': comment,
                    'type': type
                };
                goog.net.XhrIo.send("../plugins-dispatcher/sp-action", function(e) {
                    var xhr = e.target;
                    var result = xhr.getResponseJson();
                    if (result.successful) {
                        ciAction.editorHandler.setCheckedOut(false);
                        ciAction.editor.problemReporter.showInfo('Document checked in.', true);
                    } else if (result.error){
                        ciAction.editorHandler.showMessageDialog('Check in failed', result.error);
                        ciAction.editorHandler.checkIsCheckedOut();
                    }
                    callback && callback();
                }, 'POST', JSON.stringify(reqContent));
            } else {
                callback && callback();
            }
        });

        checkInDlg.show();
    }

    /** @override */
    CheckInAction.prototype.getLargeIcon = function(devicePixelRation) {
        var iconUrl = sync.util.computeHdpiIcon('../plugin-resources/sharepoint/CheckIn24.png');
        return iconUrl;
    };

    /** @override */
    CheckInAction.prototype.isEnabled = function() {
        return this.editorHandler.isCheckedOut;
    };

    /** @override */
    CheckInAction.prototype.getDescription = function() {
        return "Check in this document.";
    };

    /**
     * The action that perform a Discard Check Out operation on the current document.
     */
    var DiscardCheckOutAction = function(editor, editorHandler) {
        this.editor = editor;
        this.editorHandler = editorHandler;
    };

    /**
     * @type {string} The action's ID.
     */
    DiscardCheckOutAction.ID = 'sp.discard.checkout';

    goog.inherits(DiscardCheckOutAction, sync.actions.AbstractAction);

    /** @override */
    DiscardCheckOutAction.prototype.getDisplayName = function() {
        return 'Discard Check Out';
    };

    // The actual action execution.
    DiscardCheckOutAction.prototype.actionPerformed = function(callback) {
        var msgDialog = workspace.createDialog();
        msgDialog.setButtonConfiguration(sync.api.Dialog.ButtonConfiguration.YES_NO);
        var dialogHtml =
            '<div class="sp-message">' +
            '   If you discard your check out, you will lose all changes made to the document.' +
            '   <br/><br/>Are you sure you want to discard your check out?' +
            '</div>';
        msgDialog.getElement().innerHTML = dialogHtml;
        msgDialog.setTitle("Discard check out");

        var action = this;
        msgDialog.onSelect(function (key) {
            if (key == 'yes') {
                action.discardCheckOut(callback);
            } else {
                callback && callback();
            }
        });
        msgDialog.show();
    };

    /**
     * Discards the current check out.
     *
     * @param callback The callback function.
     */
    DiscardCheckOutAction.prototype.discardCheckOut = function(callback) {
        var reqContent = {
            action: 'discard.check.out',
            url : this.editor.options.url
        };
        var dcoAction = this;
        goog.net.XhrIo.send("../plugins-dispatcher/sp-action", function(e) {
            var xhr = e.target;
            var result = xhr.getResponseJson();
            if (result.successful) {
                dcoAction.editorHandler.setCheckedOut(false);
                dcoAction.editor.problemReporter.showInfo('Document check out discarded.', true);
                // The document should be reloaded since the user have discarded all changes.
                window.location.reload();
            } else if (result.error) {
                dcoAction.editorHandler.showMessageDialog('Discard check out failed', result.error);
                dcoAction.editorHandler.checkIsCheckedOut();
            }
            callback && callback();
        }, 'POST', JSON.stringify(reqContent));
    };

    /** @override */
    DiscardCheckOutAction.prototype.getLargeIcon = function(devicePixelRation) {
        var iconUrl = sync.util.computeHdpiIcon('../plugin-resources/sharepoint/DiscardCheckOut24.png');
        return iconUrl;
    };

    /** @override */
    DiscardCheckOutAction.prototype.isEnabled = function() {
        return this.editorHandler.isCheckedOut;
    };

    /** @override */
    DiscardCheckOutAction.prototype.getDescription = function() {
        return "Check in this document, discarding any changes you have made.";
    };

    /////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * The login manger
     */
    function SharePointLoginManager() {
        this.sessionInfo = null;
    }

    /**
     * Authenticates the current user.
     *
     * @param {function} cb The method to call after authentication
     * @param {string} contextID Used to identify the context that triggered the authentication protocol.
     */
    SharePointLoginManager.prototype.authenticateUser = function (cb, contextID) {
        if (this.sessionInfo && this.sessionInfo.isConfigured && this.sessionInfo.isAuth) {
            cb();
        } else {
            var self = this;
            var xhr = new goog.net.XhrIo();
            goog.events.listen(xhr, goog.net.EventType.COMPLETE, function(e) {
                var status = this.getStatus();
                if (status === 200) {
                    var response = this.getResponse();
                    if (response && response != '') {
                        var sessionInfo = JSON.parse(response);
                        self.setSessionInfo(sessionInfo);
                        if (sessionInfo) {
                            if (sessionInfo.isConfigured) {
                                if (sessionInfo.isAuth) {
                                    cb();
                                } else {
                                    self.showLoginDialog(contextID);
                                }
                            } else {
                                self.showConfigDialog();
                            }
                        }
                    }
                } else if (status >= 100) {
                    self.showLoginDialog();
                }
            });
            xhr.send(
                '../plugins-dispatcher/sp-session',
                'GET',
                null,
                // Disable cache
                {
                    "Cache-Control" : "no-cache, no-store, must-revalidate, private",
                    "Pragma": "no-cache",
                    "Expires": 0
                });
        }
    };

    /**
     * Updates the info for the current session.
     *
     * @param sessionInfo Relevant data about the current session.
     */
    SharePointLoginManager.prototype.setSessionInfo = function (sessionInfo) {
        this.sessionInfo = sessionInfo;
    };

    /**
     * Shows the login dialog.
     * @param {string} contextID Used to identify the context that triggered the login dialog.
     */
    SharePointLoginManager.prototype.showLoginDialog = function (contextID) {
        var loginDialog = workspace.createDialog();
        loginDialog.setButtonConfiguration(sync.api.Dialog.ButtonConfiguration.CANCEL);

        var dialogHtml = '<div class="sp-login-dialog">';

        dialogHtml += '<div id="sp-login-button-container"></div>';

        loginDialog.getElement().innerHTML = dialogHtml;
        loginDialog.setTitle("Office 365 Login");

        // Pressing cancel while on the dashboard page shouldn't reload the page
        if (!isOnDashboard) {
            loginDialog.onSelect(function (key) {
                if (key == 'cancel') {
                    // Go to the dashboard view
                    window.location.href = window.location.protocol + "//" + window.location.hostname +
                      (window.location.port ? ':' + window.location.port : '') + window.location.pathname;
                }
            });
        }

		// Append the ID of the current performed action
        var location = window.location;
        if (contextID) {
            location += '#' + encodeURIComponent(contextID);
        }
        var state = "&state=" + encodeURIComponent(location);
        var oauthUrl = "../plugins-dispatcher/sp-oauth?init" + state;
        var loginButtonContainer = loginDialog.dialog.getElement().querySelector('#sp-login-button-container');
        loginButtonContainer.innerHTML =
            'To access files stored on your SharePoint Online site you must login using your Office 365 account.' +
            '<a title="Click to login using your Office 365 account" rel="external" href="' +
            oauthUrl +
            '" id="sp-oauth-button"><span class="sp-icon-large"></span><span class="sp-oauth-text">Login with Office 365</span></a>';

        loginDialog.show();
    };

    /**
     * Shows the OAuth configuration warning dialog.
     */
    SharePointLoginManager.prototype.showConfigDialog = function () {
        var loginDialog = workspace.createDialog();
        loginDialog.setButtonConfiguration(sync.api.Dialog.ButtonConfiguration.CANCEL);

        var dialogHtml = '<div class="sp-login-dialog sp-login-dialog-error">' +
            '   <div>The SharePoint plugin is not configured properly.' +
            '       If you are the administrator of the application make sure' +
            '       the OAuth parameters are properly set in the <a target="_blank" href="admin.html#Plugins">administration page</a>.' +
            '   </div>' +
            '</div>';

        loginDialog.getElement().innerHTML = dialogHtml;
        loginDialog.setTitle("Office 365 Login");

        loginDialog.onSelect(function (key) {
            if (key == 'cancel') {
                // Go to the dashboard view
                window.location.href = window.location.protocol + "//" + window.location.hostname +
                    (window.location.port ? ':' + window.location.port : '') + window.location.pathname;
            }
        });

        loginDialog.show();
    };

    // A sharepoint-specific file browser.
    var SharePointFileBrowser = function () {
        var latestUrl = localStorage.getItem('sharepoint.latestUrl');
        sync.api.FileBrowsingDialog.call(this, {
            initialUrl: latestUrl
        });
    };
    goog.inherits(SharePointFileBrowser, sync.api.FileBrowsingDialog);

    /** @override */
    SharePointFileBrowser.prototype.renderRepoPreview = function(element) {
        var url = this.getCurrentFolderUrl();
        if (url) {
            element.style.paddingLeft = '5px';
            element.title = "Server URL";

            element.innerHTML = '<div class="domain-icon" style="' +
                'background-image: url(' + sync.util.getImageUrl('/images/SharePointWeb16.png', sync.util.getHdpiFactor()) + ');"></div>' +
                new sync.util.Url(url).getDomain() +
                '<div class="sharepoint-domain-edit"></div>';
            var button = element.querySelector('.sharepoint-domain-edit');
            button.title = "Edit server URL";
            goog.events.listen(button, goog.events.EventType.CLICK,
                goog.bind(this.switchToRepoConfig, this, element))
        }
    };

    /** @override */
    SharePointFileBrowser.prototype.renderRepoEditing = function (element) {
        var self = this;
        self.renderResourcesChooser(element);

        var resources = [];
        if (loginManager.sessionInfo && loginManager.sessionInfo.resources) {
            resources = loginManager.sessionInfo.resources;
        }
        self.resourcePicker.gotPossibleResources(resources);
        self.dialog.setPreferredSize(null, 200);
    };

    /**
     * @param {HTMLELement} container The html element in which we'll render the resouces.
     */
    SharePointFileBrowser.prototype.renderResourcesChooser = function (container) {
        container.innerHTML =
            '<div class="sp-resources-input-wrapper">' +
            '<input id="sp-resources-input" placeholder="Choose or enter the SharePoint site to browse" />' +
            '</div>';

        var resourceInputELement = container.querySelector('#sp-resources-input');
        this.resourcePicker = new SharepointResourcesPicker(resourceInputELement);
    };

    /**
     * @param {HTMLInput} input The input element to enhance with selection capabilities.
     */
    function SharepointResourcesPicker(input) {
        this.renderer = new goog.ui.ac.Renderer(input.parentNode);
        this.inputhandler = new goog.ui.ac.InputHandler(null, null, false, 300);
        this.ac = new goog.ui.ac.AutoComplete(this, this.renderer, this.inputhandler);
        this.inputhandler.attachAutoComplete(this.ac);
        this.inputhandler.attachInputs(input);
        this.ac.setAutoHilite(false);

        this.eventHandler = new goog.events.EventHandler(this);
        // On focus, expand the suggestions list.
        this.eventHandler.listen(input, goog.events.EventType.FOCUS, goog.bind(function() {
            this.ac.getSelectionHandler().update(true);
        }, this));
    }
    goog.inherits(SharepointResourcesPicker, goog.events.EventTarget);

    /*
     * @param {Array<string>} resources A list of the available resources.
     */
    SharepointResourcesPicker.prototype.gotPossibleResources = function (resources) {
        this.resources = resources;

        if (this.handler_) {
            this.requestMatchingRows(this.token_, this.maxMatches_, this.handler_);
            this.handler_ = null;
            this.maxMatches_ = null;
            this.token_ = null;
        }
    };

    /** @override */
    SharepointResourcesPicker.prototype.requestMatchingRows = function (token, maxMatches, matchHandler, opt_fullString) {
        if (this.resources) {
            this.handler_ = matchHandler;
            this.token_ = token;
            this.maxMatches_ = maxMatches;
            matchHandler(token, this.resources);
        } else {
            this.handler_ = matchHandler;
            this.token_ = token;
            this.maxMatches_ = maxMatches;
        }
    };

    /** @override */
    SharePointFileBrowser.prototype.handleOpenRepo = function (element, e) {
        // Get value from resource picker here

        var url = document.getElementById('sp-resources-input').value;
        // if an url was provided we instantiate the file browsing dialog.
        if(url) {
            var processedUrl = this.processURL(url);
            localStorage.setItem('sharepoint.latestUrl', processedUrl);

            this.openUrl(processedUrl, false, e);
        }
    };


    /**
     * Further processes the url.
     *
     * @param url the url to process.
     *
     * @return {string} the processed url.
     */
    SharePointFileBrowser.prototype.processURL = function(url) {
        var processedUrl = url;

        // if the url does not start with 'spo' prepend it to the url.
        if(!(url.indexOf('spo-') == 0)) {
            processedUrl = 'spo-' + processedUrl;
        }
        // if the url does not end in a '/' we add it.
        if(!(processedUrl.substring(processedUrl.length - 1) ==  "/")) {
            processedUrl = processedUrl + "/"
        }
        return processedUrl;
    };

    /**
     * Register all the needed listeners on the file browser.
     *
     * @param {sync.api.FileBrowsingDialog} fileBrowser
     *  the file browser on which to listen.
     */
    var registerFileBrowserListeners = function (fileBrowser) {
        // handle the user action required event.
        var eventTarget = fileBrowser.getEventTarget();

        goog.events.listen(eventTarget,
            sync.api.FileBrowsingDialog.EventTypes.USER_ACTION_REQUIRED,
            goog.bind(loginManager.showLoginDialog, loginManager));
    };

    var loginManager = new SharePointLoginManager();

    var editorHandler = new SharePointEditorHandler();

    // create the connection configurator.
    var fileBrowser = new SharePointFileBrowser();

    // register all the listeners on the file browser.
    registerFileBrowserListeners(fileBrowser);

    // A sharepoint-specific open action.
    var SharePointOpenAction = function (fileBrowser) {
        // Initialize super type
        sync.actions.OpenAction.call(this, fileBrowser);

        // the large icon url, hidpi enabled.
        var iconUrl = sync.util.computeHdpiIcon('../plugin-resources/sharepoint/SharePoint70.png');
        this.setLargeIcon(iconUrl);
        this.setDescription('Open document from your SharePoint Online site');
        this.setActionId(SharePointOpenAction.ID);
        this.setActionName('SharePoint');
    };
    SharePointOpenAction.ID = 'sharepoint-open-action';

    goog.inherits(SharePointOpenAction, sync.actions.OpenAction);

    /**@override*/
    SharePointOpenAction.prototype.actionPerformed = function () {
        loginManager.authenticateUser(goog.bind(SharePointOpenAction.superClass_.actionPerformed, this), SharePointOpenAction.ID);
    };

    // A sharepoint-specific create document action.
    var SharePointCreateDocumentAction = function(fileBrowser) {
        // Initialize super type
        sync.api.CreateDocumentAction.call(this, fileBrowser);

        // the large icon url, hidpi enabled.
        var iconUrl = sync.util.computeHdpiIcon('../plugin-resources/sharepoint/SharePoint70.png');
        this.setLargeIcon(iconUrl);
        this.setDescription('Create a new document on your SharePoint Online site');
        this.setActionId(SharePointCreateDocumentAction.ID);
        this.setActionName('SharePoint');
    };

    SharePointCreateDocumentAction.ID = 'sharepoint-create-action';

    goog.inherits(SharePointCreateDocumentAction, sync.api.CreateDocumentAction);

    /**@override*/
    SharePointCreateDocumentAction.prototype.actionPerformed = function () {
        loginManager.authenticateUser(goog.bind(SharePointCreateDocumentAction.superClass_.actionPerformed, this), SharePointCreateDocumentAction.ID);
    };

    // Initialize and register the Open & Create Document actions
    var sharepointOpenAction = new SharePointOpenAction(fileBrowser);
    var sharepointCreateAction = new SharePointCreateDocumentAction(fileBrowser);

    var actionsManager = workspace.getActionsManager();
    actionsManager.registerOpenAction(sharepointOpenAction);
    actionsManager.registerCreateAction(sharepointCreateAction);

    sync.util.loadCSSFile("../plugin-resources/sharepoint/sharepoint.css");
})();